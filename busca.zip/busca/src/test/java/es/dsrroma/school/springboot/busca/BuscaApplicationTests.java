package es.dsrroma.school.springboot.busca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuscaApplicationTests {

	@Test
	void contextLoads() {
	}

}
