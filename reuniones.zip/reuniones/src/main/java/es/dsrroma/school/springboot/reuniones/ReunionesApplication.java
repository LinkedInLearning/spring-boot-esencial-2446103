package es.dsrroma.school.springboot.reuniones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReunionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReunionesApplication.class, args);
	}

}
