package es.dsrroma.school.springboot.reuniones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReunionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
